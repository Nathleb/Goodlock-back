import { DieFace } from "../../interfaces/DieFace.interface";
import { Character } from "../../models/Character.model";
import { Group } from "../../types/Groups.type";
import { Position } from "../../types/Position.type";
import { DieFaceDecorator } from "./DieFaceDecorator.decorator";

export class SingleTargetHealingDecorator extends DieFaceDecorator {
    private healingAmount: number;

    constructor(dieFace: DieFace, healingAmount: number) {
        super(dieFace);
        this.healingAmount = healingAmount;
    }

    effect(target?: Character | Position | Group): void {
        this.decoratedDieFace.effect(target);
        console.log(`Healing ${target} for ${this.healingAmount}`);
    }
}
