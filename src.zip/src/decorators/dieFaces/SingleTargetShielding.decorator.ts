import { DieFace } from "../../interfaces/DieFace.interface";
import { Character } from "../../models/Character.model";
import { Group } from "../../types/Groups.type";
import { Position } from "../../types/Position.type";
import { DieFaceDecorator } from "./DieFaceDecorator.decorator";

export class SingleTargetShieldingDecorator extends DieFaceDecorator {
    private shieldingAmount: number;

    constructor(dieFace: DieFace, shieldingAmount: number) {
        super(dieFace);
        this.shieldingAmount = shieldingAmount;
    }

    effect(target?: Character | Position | Group): void {
        this.decoratedDieFace.effect(target);
        console.log(`shielding ${target} for ${this.shieldingAmount}`);
    }
}
