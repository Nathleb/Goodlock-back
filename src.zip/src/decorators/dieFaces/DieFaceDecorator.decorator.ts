import { DieFace } from "../../interfaces/DieFace.interface";
import { Character } from "../../models/Character.model";
import { Group } from "../../types/Groups.type";
import { Position } from "../../types/Position.type";


export abstract class DieFaceDecorator implements DieFace {
    protected decoratedDieFace: DieFace;

    constructor(dieFace: DieFace) {
        this.decoratedDieFace = dieFace;
    }

    abstract effect(target?: Character | Position | Group): void;
}