import { DieFace } from "../../interfaces/DieFace.interface";
import { Character } from "../../models/Character.model";
import { Group } from "../../types/Groups.type";
import { Position } from "../../types/Position.type";
import { DieFaceDecorator } from "./DieFaceDecorator.decorator";

export class SingleTargetDamageDecorator extends DieFaceDecorator {
    private damageAmount: number;

    constructor(dieFace: DieFace, damageAmount: number) {
        super(dieFace);
        this.damageAmount = damageAmount;
    }

    effect(target?: Character | Position | Group): void {
        this.decoratedDieFace.effect(target);
        console.log(`Damage ${target} for ${this.damageAmount}`);
    }
}
