import { BasicDieFace } from "./BasicDieFace.model";

export class Die {
    faces: BasicDieFace[];

    constructor() {
        this.faces = new Array(6);
    }
}