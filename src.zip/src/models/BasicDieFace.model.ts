import { DieFace } from "../interfaces/DieFace.interface";
import { Group } from "../types/Groups.type";
import { Position } from "../types/Position.type";
import { Character } from "./Character.model";

export class BasicDieFace implements DieFace {
    priority: number = 0;

    effect(target?: Character | Position | Group): void {
        console.log("");
    }

}