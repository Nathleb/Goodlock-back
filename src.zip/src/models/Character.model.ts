import { Position } from "../types/Position.type";
import { Die } from "./Die.model";

export class Character {
    name: string;
    maxHp: number;
    baseDie: Die;

    currentHp: number;
    currentDie: Die;
    position: Position;

    constructor(name: string, maxHp: number, baseDie: Die, position: Position) {
        this.name = name;
        this.maxHp = maxHp;
        this.currentHp = maxHp;
        this.baseDie = baseDie;
        this.currentDie = baseDie;
        this.position = position;
    }
}