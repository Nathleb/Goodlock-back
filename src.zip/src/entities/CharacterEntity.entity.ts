import { Die } from "../models/Die.model";

export class CharacterEntity {
    name: string;
    maxHp: number;
    baseDie: Die;

    constructor(name: string, maxHp: number, baseDie: Die) {
        this.name = name;
        this.maxHp = maxHp;
        this.baseDie = baseDie;
    }
}