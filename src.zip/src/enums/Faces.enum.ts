export enum Faces {
    LeftFace = 0,
    CenterFace = 1,
    RightFace = 2,
    RightRightFace = 3,
    TopFace = 4,
    BottomFace = 5
}