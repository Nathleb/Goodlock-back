import { DieFace } from "./interfaces/DieFace.interface";
import { BasicDieFace } from "./models/BasicDieFace.model";
import { SingleTargetDamageDecorator } from "./decorators/dieFaces/SingleTargetDamage.decorator";
import { SingleTargetHealingDecorator } from "./decorators/dieFaces/SingleTargetHealing.decorator";
import { SingleTargetShieldingDecorator } from "./decorators/dieFaces/SingleTargetShielding.decorator";

function main() {


    let face: DieFace = new SingleTargetDamageDecorator(new BasicDieFace(), 3);
    face = new SingleTargetDamageDecorator(face, 2);
    face = new SingleTargetHealingDecorator(face, 2);
    face = new SingleTargetHealingDecorator(face, 2);
    face = new SingleTargetShieldingDecorator(face, 2);
    face = new SingleTargetShieldingDecorator(face, 2);
    face = new SingleTargetShieldingDecorator(face, -1);


    face.effect(2);
}

main();
