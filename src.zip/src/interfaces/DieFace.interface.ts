import { Character } from "../models/Character.model";
import { Group } from "../types/Groups.type";
import { Position } from "../types/Position.type";

export interface DieFace {
    effect(target?: Character | Position | Group): void;
}